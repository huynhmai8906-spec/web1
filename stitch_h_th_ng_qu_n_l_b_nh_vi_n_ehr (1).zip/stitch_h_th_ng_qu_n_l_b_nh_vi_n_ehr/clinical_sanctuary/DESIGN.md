---
name: Clinical Sanctuary
colors:
  surface: '#f8f9ff'
  surface-dim: '#F0F4F4'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4fe'
  surface-container: '#eaeef9'
  surface-container-high: '#e4e8f3'
  surface-container-highest: '#dee2ed'
  on-surface: '#171c23'
  on-surface-variant: '#3f4947'
  inverse-surface: '#2c3139'
  inverse-on-surface: '#edf1fb'
  outline: '#6f7978'
  outline-variant: '#bec9c7'
  surface-tint: '#216964'
  primary: '#004340'
  on-primary: '#ffffff'
  primary-container: '#0d5c58'
  on-primary-container: '#8ed2cc'
  inverse-primary: '#8fd3cd'
  secondary: '#426086'
  on-secondary: '#ffffff'
  secondary-container: '#b3d1fd'
  on-secondary-container: '#3c597f'
  tertiary: '#4e3700'
  on-tertiary: '#ffffff'
  tertiary-container: '#6a4d0c'
  on-tertiary-container: '#e8c075'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#abefe9'
  primary-fixed-dim: '#8fd3cd'
  on-primary-fixed: '#00201e'
  on-primary-fixed-variant: '#00504c'
  secondary-fixed: '#d3e4ff'
  secondary-fixed-dim: '#abc8f4'
  on-secondary-fixed: '#001c38'
  on-secondary-fixed-variant: '#2a486d'
  tertiary-fixed: '#ffdea5'
  tertiary-fixed-dim: '#e9c176'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5d4201'
  background: '#f8f9ff'
  on-background: '#171c23'
  surface-variant: '#dee2ed'
  emerald-deep: '#0D5C58'
  sapphire-dispatch: '#1B3B5F'
  clinical-amber: '#C5A059'
  emergency-red: '#BA1A1A'
  telehealth-teal: '#147A74'
  vital-stable: '#2E6B47'
  surface-clean: '#FBFDFD'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 44px
    fontWeight: '500'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: 0em
  headline-md:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Manrope
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an authoritative, high-tier clinical environment balancing rigorous surgical precision with concierge healthcare hospitality. Built for intensive multi-disciplinary workflows—including Clinical EHR, Telehealth suites, Inpatient Pharmacy, and Emergency Medical Dispatch—the aesthetic avoids both sterile brutality and consumer frivolity.

The aesthetic philosophy draws on **Modern Clinical Prestige**:
- **Purity and Cleanliness:** Crisp, high-contrast surfaces inspired by international quaternary hospitals and precision cleanrooms, ensuring rapid cognitive intake under emergency conditions.
- **Academic & Clinical Authority:** High-legibility editorial serif titles convey diagnostic gravitas and medical pedigree, grounded by an engineered, ergonomic sans-serif for dense vitals, dosage calculations, and HL7/FHIR telemetry.
- **Restrained Luxury:** Subtle, deep surgical emerald paired with muted gold-amber accents signifies world-class VIP clinical suites, reassuring patients while reducing eye fatigue during 12-hour practitioner shifts.

## Colors

The palette delivers strict clinical differentiation, accessibility compliance (WCAG AAA for critical telemetry), and an unmistakable visual signature of premium healthcare:

- **Primary (`#0D5C58` - Surgical Emerald):** Anchors institutional identity, primary triage states, high-priority interactive workflows, and top-level navigation.
- **Secondary (`#1B3B5F` - Sapphire Navy):** Governs complex operational frameworks: inpatient bed management, pharmacy formularies, diagnostic imaging metadata, and active HL7/FHIR stream indicators.
- **Tertiary (`#C5A059` - Clinical Gold/Amber):** Applied sparingly to concierge status designations, VIP patient indicators, advisory flags, and pending lab authentications.
- **Neutral (`#2C3139` - Obsidian Slate):** Provides high-clarity typography on light surfaces without the stark harshness of pure black.
- **Semantic Accents:**
  - `emergency-red` (`#BA1A1A`): Immediate resuscitation alerts, code blue calls, critical vitals drops, and allergy warnings.
  - `vital-stable` (`#2E6B47`): Validated test results, stable vitals ranges, and verified dispense confirmations.
  - `telehealth-teal` (`#147A74`): Active video sessions, peer-to-peer consultations, and real-time patient-facing portals.

## Typography

Typography pairs institutional academic gravitas with clinical execution clarity:

- **Headlines (Newsreader):** Used for clinical summaries, consultation titles, diagnostic overviews, and department portals. It introduces warmth and timeless prestige, differentiating this system from utilitarian commodity software.
- **Body & Labels (Manrope):** Geometric, highly legible, and structurally balanced. Manrope excels at tabular diagnostic parameters, dosage instructions, blood gas levels, and real-time dispatch telemetry.
- **Numerical Alignment:** All numerical vital indicators, dosages, and timestamps must render with tabular figures (`tnum`) to maintain vertical scanning fidelity across inpatient charts.

## Layout & Spacing

The layout is built upon an adaptive 12-column fluid grid tailored for high-density diagnostic data visualization and emergency response coordination:

- **Desktop (1440px+):** 12-column layout with fixed split-pane navigation. Dedicated left console (patient demographics & triage index), central diagnostic canvas (EHR chart/telehealth stage), and collapsible right-hand telemetry (vitals stream, active orders, HL7 event log).
- **Tablet / Workstation on Wheels (768px - 1439px):** Adaptive 8-column layout with drawer-based peripheral telemetry. Touch targets expand to accommodate clinical gloved interaction.
- **Mobile Handheld (Dispatch & Resident On-Call <768px):** 4-column linear layout. Navigation condenses to situational actions: triage callout, code alert, and medication scanning.
- **Rhythm & Safe Density:** Clinical dashboards maintain structured information hierarchy. Critical patient data containers use `space-md` inner padding, avoiding crowded forms while preserving sufficient field density for rapid multi-factor review.

## Elevation & Depth

Visual hierarchy leverages calm, low-strain tonal stratification combined with soft, non-invasive ambient shadowing:

- **Level 0 (Clinical Floor):** Pristine background `#FBFDFD` or subdued tint `#F0F4F4`. Neutral, distraction-free environment.
- **Level 1 (Clinical Cards & Vitals Modules):** Pure white `#FFFFFF` surface bordered with a refined `1px` subtle outline (`rgba(13, 92, 88, 0.10)`). Ambient shadow: `0px 2px 8px -2px rgba(44, 49, 57, 0.04)`.
- **Level 2 (Telemetry Panels, Prescription Staging):** Elevated operational surfaces. Ambient shadow: `0px 8px 24px -4px rgba(13, 92, 88, 0.08)`.
- **Level 3 (Emergency Modals, Drug Interaction Overrides, Telehealth Overlays):** High-priority focus layers. Ambient shadow: `0px 16px 36px -6px rgba(27, 59, 95, 0.16)`. Accompanied by a surgical backdrop blur (`backdrop-filter: blur(8px)`) tinted with dark slate at 25% opacity.

## Shapes

The interface adopts a disciplined roundedness level of `2`:
- Standard structural elements (cards, input fields, clinical chart blocks) utilize `0.5rem` (8px) corner radii.
- Medium modal containers, telehealth viewports, and medication review cards use `rounded-lg` (`1rem` / 16px).
- Badges, status pills (e.g., triage tier, code status), and quick-action prescription tags retain fully curved pill geometry (`9999px`) to distinguish categorical metadata from interactive rectangular fields.

## Components

### Buttons
- **Primary Clinical Action:** Solid `#0D5C58` background with `#FFFFFF` text. Height 44px, border-radius 8px. Subtle hover darkening (`#094441`). Used for actions such as "Sign & Order", "Authorize Dispatch", and "Initiate Tele-consult".
- **Secondary (Operational):** Outlined with `1px` solid `#0D5C58`, transparent background, `#0D5C58` text. Hover transitions into a 6% emerald tint.
- **Urgent / Danger Action:** Solid `#BA1A1A` background with crisp white text. Elevated with an alert halo on focus (`0 0 0 3px rgba(186, 26, 26, 0.25)`).

### Input Fields & Clinical Selectors
- Background: Clean white `#FFFFFF`.
- Border: `1px` solid `#D1D8D8`. Height 44px.
- Focus state: Border transitions to `#0D5C58` with a continuous `3px` ambient ring of `rgba(13, 92, 88, 0.15)`.
- Critical alert state (e.g., allergic drug interaction, invalid dosing): Border flashes `#BA1A1A` with an integrated leading warning glyph and micro-caption explaining clinical contraindications.

### Cards & Vitals Panels
- Composed on Level 1 elevation with a clean `#FFFFFF` baseline and hairline boundary.
- Header bands incorporate Newsreader typography (`title-lg` or `headline-sm`) offset by Manrope status tags.
- Vitals indicators display standard values alongside micro-trend sparklines in `vital-stable` or `emergency-red`.

### Chips & Clinical Status Badges
- **Triage Chips:** Pill-shaped with strict clinical contrast. High triage (Red-1) utilizes `#FFDAD6` fill with `#93000A` bold text; Routine uses `#E0F2F1` fill with `#0D5C58` text.
- **FHIR Resource Badges:** Slate-tinted tags highlighting standard resources (`Patient`, `Observation`, `Encounter`) with monospace-styled sub-labels.

### Checkboxes & Radios
- Square 20x20mm equivalent with 4px border radius for checkboxes, circular 20px for radios.
- Unchecked: `1.5px` border in `#6C757D`. Checked: Solid `#0D5C58` with high-contrast white checkmark icon.

### Emergency Dispatch & Telehealth Stream
- Dedicated responsive video/audio frame with subtle inner border and rounded-lg corners. Overlay controls use semi-transparent frosted navy panels (`rgba(27, 59, 95, 0.85)`) with pure white icon glyphs for diagnostic clarity during low-light nighttime operations.